package com.javarush.jira.bugtracking;

public enum ObjectType {
    PROJECT,
    SPRINT,
    TASK
}
