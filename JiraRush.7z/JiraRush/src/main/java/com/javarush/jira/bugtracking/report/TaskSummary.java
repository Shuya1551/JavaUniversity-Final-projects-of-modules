package com.javarush.jira.bugtracking.report;

public record TaskSummary(String status, long total) {
}
