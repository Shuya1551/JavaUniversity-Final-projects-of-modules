package com.javarush.jira.profile.internal.web;

import com.javarush.jira.AbstractControllerTest;


class ProfileRestControllerTest extends AbstractControllerTest {



}