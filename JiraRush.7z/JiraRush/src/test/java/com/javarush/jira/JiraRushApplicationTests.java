package com.javarush.jira;

import org.junit.jupiter.api.Test;

class JiraRushApplicationTests extends BaseTests {
    @Test
    void contextLoads() {
    }
}
