package com.javarush.jira.common.util;

import org.junit.jupiter.api.Test;

// TODO
class UtilTest {

    @Test
    void makeTree() {
/*
        NodeTo a = new NodeTo(1L, "A", true, "A", "A", "A", null);
        NodeTo b = new NodeTo(1L, "B", true, "B", "B", "B", a);
        NodeTo c = new NodeTo(1L, "C", true, "C", "C", "C", a);
        NodeTo d = new NodeTo(1L, "D", true, "D", "D", "D", b);
        NodeTo e = new NodeTo(1L, "E", true, "E", "E", "E", d);
        List<NodeTo> projects = List.of(e, b, c, d, a);

        List<TreeNode> nodes = Util.makeTree(projects);
        for (TreeNode treeNode : nodes) {
            System.out.println(treeNode);
        }
*/
    }
}